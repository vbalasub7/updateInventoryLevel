import boto3
import pandas as pd
from io import StringIO
from datetime import datetime

def lambda_handler(event, context):
    # Initialize S3 client
    s3_client = boto3.client('s3')
    
    # S3 bucket and file details
    source_bucket = 'aws-supply-chain-data-7f724484-d97d-4c0c-a9cb-d7895364a8f9'
    target_bucket = 'output29422'
    file_key = 'othersources/inventorylevel_records/InventoryLevel_Records.csv'
    
    try:
        # Read CSV file from S3
        response = s3_client.get_object(Bucket=source_bucket, Key=file_key)
        csv_content = response['Body'].read().decode('utf-8')
        
        # Convert CSV to DataFrame
        df = pd.read_csv(StringIO(csv_content))
        
        # Update snapshot_date field with current date in ISO format
        current_date = datetime.now().isoformat()  # Format: YYYY-MM-DDTHH:MM:SS.mmmmmm+HH:MM
        # Alternative: If you want to truncate microseconds
        # current_date = datetime.now().replace(microsecond=0).isoformat()
        
        df['snapshot_date'] = current_date
        
        # Convert DataFrame back to CSV
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)
        
        # Upload updated file to source bucket
        s3_client.put_object(
            Bucket=source_bucket,
            Key=file_key,
            Body=csv_buffer.getvalue()
        )
        
        # Upload updated file to target bucket
        s3_client.put_object(
            Bucket=target_bucket,
            Key=file_key,
            Body=csv_buffer.getvalue()
        )
        
        return {
            'statusCode': 200,
            'body': f'Successfully updated CSV file in both buckets with snapshot date: {current_date}'
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f'Error: {str(e)}'
        }
